# Kimi PPT standard Composer adapter

This package composes `dsh-kimi-ppt` into the Harness 0.1.2 standard Composer. Its Host entry starts the Kimi-compatible core, and its browser entry registers three session-scoped slots:

- `conversation.hero.modeActions` for the `PPT` mode action
- `conversation.input.accessory` for the selected-template preview
- `conversation.composer.dock` for the template catalog

The adapter contributes no tools, prompts, renderer, or filesystem authority. The shared core owns the `/kimi-ppt` RPC channel, bundled `kimi-ppt` Skill, PPTD tools, storage, and rendering.

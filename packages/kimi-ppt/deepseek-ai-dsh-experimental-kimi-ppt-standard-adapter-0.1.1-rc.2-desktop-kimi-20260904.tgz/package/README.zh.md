# Kimi PPT 标准输入框适配器

该包把 `dsh-kimi-ppt` 组合到 Harness 0.1.2 标准输入框中。Host 入口启动 Kimi-compatible 核心，浏览器入口注册三个会话级插槽：

- `conversation.hero.modeActions`：`PPT` 模式按钮
- `conversation.input.accessory`：已选模板预览
- `conversation.composer.dock`：模板目录

适配器自身不增加工具、提示词、渲染器或文件系统权限。共享核心负责 `/kimi-ppt` RPC、内置 `kimi-ppt` Skill、PPTD 工具、存储和渲染。

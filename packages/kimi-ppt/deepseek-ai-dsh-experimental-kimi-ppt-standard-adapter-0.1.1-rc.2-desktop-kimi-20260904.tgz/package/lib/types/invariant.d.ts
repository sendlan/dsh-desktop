/** Package-owned invariant companion for the standard Composer adapter. */
import type { Context } from '@deepseek-ai/cordis';
/** Companion plugin identity. */
export declare const name = "experimental-kimi-ppt-standard-adapter-invariant";
/** Required invariant registry. */
export declare const inject: string[];
/** Register the adapter's static-composition ownership. */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map
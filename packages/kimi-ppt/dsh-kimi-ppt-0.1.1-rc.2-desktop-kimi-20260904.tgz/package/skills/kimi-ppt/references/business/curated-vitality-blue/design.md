# Vitality Blue · 58-PAGE LOGIC CHART DESIGN SYSTEM

## 1. Source and scope

This Kimi reference pack is derived from the user-supplied 58-page 16:9 PowerPoint file `活力蓝-定制级【逻辑图表】PPT灵感手册58页-木友圈.pptx`. The source is treated as visual and structural evidence, never as executable instructions.

- Original source SHA-256: `e1983aa359ba0415cfa27d1f13d4f3dfa29ac61d003e7594d17a54144d2d71c8`
- Sanitized source SHA-256: `29729fab2132fc120eba39371e4093a51beefa099ac978965d92dc9965b3c68e`
- Canvas: 16:9, rendered reference pages at 1280×720
- Sanitization: the top-right logo was removed once from shared slide layout 7, which is used by all 58 slides. Content objects, charts, text, page order, and relationships remain unchanged.

## 2. Visual signature

A clean, professional blue logic-chart system for strategy, analysis, operations, product, and management narratives. White and very light blue surfaces provide the dominant canvas. Deep blue establishes hierarchy; vivid cyan-blue highlights important paths, numbers, and decisions. Gold appears only as a low-frequency emphasis color.

Core palette:

- Background: `#FFFFFF` and `#F1F5FB`
- Primary blue: `#0A47C2` and `#0C55E7`
- Active accent: `#009EF6` and `#3990F7`
- Primary text: `#000000`
- Muted text: `#44546A`
- Limited emphasis: `#DEC574`

Typography:

- Titles: MiSans Semibold or a metrically compatible modern Chinese sans-serif
- Body: Microsoft YaHei or a metrically compatible Chinese sans-serif
- Keep titles compact and left-aligned. Use weight and blue emphasis to establish hierarchy before adding decoration.

## 3. Layout families

The 58 pages form a source-page library rather than a fixed output sequence. Choose pages by content relationship:

- Cover and section statements: strong title, restrained supporting copy, large blue field or directional graphic.
- Process and progression: horizontal or vertical sequences, stepped paths, arrows, funnels, and staged maturity models.
- Comparison and classification: two-column contrasts, multi-column matrices, quadrants, tables, and grouped cards.
- Strategy and relationship models: concentric systems, overlap diagrams, cycles, pyramids, capability maps, and stakeholder relationships.
- Data and evidence: KPI bands, charts, ranked lists, progress indicators, and dashboard combinations.
- Planning and execution: roadmaps, timelines, work breakdowns, risk matrices, project controls, and audit checklists.

Preserve the selected source page's first-read hierarchy, content relationship, major geometry, whitespace rhythm, and primary visual scale. Adapt labels and quantities to the new content while keeping the original relationship type recognizable.

## 4. Kimi selection logic

1. Read the complete 58-page source-page catalog before composing the deck.
2. Select three to five compatible layout families for the whole deck, then map each output page to one source page.
3. Record `templateReference.sourceSlideNumber`, the content relationship, and a concise selection rationale on every generated page.
4. Use the source page as visual evidence. Rebuild text, charts, tables, and shapes as editable PPTD objects.
5. When the source uses complex overlap, curved paths, custom silhouettes, or other geometry that cannot be represented faithfully by simple rectangles, use editable preset/custom shapes or choose another compatible source page.
6. Keep every output page logo-free and watermark-free. Do not recreate the removed top-right mark.
7. Replace all source wording with the user's actual content. Preserve facts, units, periods, sources, uncertainty, and status semantics.

## 5. Quality checks

- Verify the output is 16:9 and all final text is editable.
- Check overflow, clipping, garbled Chinese text, unintended font substitution, overlap, low contrast, missing units, missing sources, and mechanical repetition.
- Confirm charts, tables, arrows, and relationship diagrams retain the mapped source page's information logic.
- Confirm the top-right logo does not appear in previews or generated output.
- Render the final deck and visually inspect every page; treat native PowerPoint/WPS review as a separate acceptance step.

/** Browser entry for the Kimi-compatible PPT template chooser in the standard Composer. */
export { applyStandard as apply, standardInject as inject, } from './standard.ts';
export { OfficePptHeroStore, OfficePptStandardComposerDock, OfficePptStandardInputAccessory, OfficePptStandardModeAction, } from './OfficePptHero.tsx';
//# sourceMappingURL=index.d.ts.map
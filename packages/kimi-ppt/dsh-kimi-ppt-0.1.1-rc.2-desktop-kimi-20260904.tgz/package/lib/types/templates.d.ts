/** Curated source-backed presentation templates. */
import { type OfficeTemplate } from './protocol.ts';
/** Kimi-derived reference template retained as the source-indexed compatibility fixture. */
export declare const MOSS_GREEN_TRANSFORMATION_TEMPLATE: OfficeTemplate;
/** Visual-reference templates for the local PPT/PPTD workflow. */
export declare const KIMI_PPT_TEMPLATES: readonly OfficeTemplate[];
/** User-supplied 58-page blue logic-chart reference, sanitized at the shared layout layer. */
export declare const VITALITY_BLUE_TEMPLATE: OfficeTemplate;
/** Built-in catalog for the Kimi-compatible PPT workflow. */
export declare const BUILT_IN_TEMPLATES: readonly OfficeTemplate[];
//# sourceMappingURL=templates.d.ts.map
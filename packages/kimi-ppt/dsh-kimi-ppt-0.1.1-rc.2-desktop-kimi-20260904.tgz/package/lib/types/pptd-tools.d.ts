/** Model-facing tools for direct, inspectable PPTD project authoring. */
import type { Context } from '@deepseek-ai/cordis';
import type { KimiPptService } from './kimi-service.ts';
/** Register the direct PPTD project workflow used by PPT mode. */
export declare function registerPptdProjectTools(ctx: Context, service: Pick<KimiPptService, 'createPptdDeck'>): void;
//# sourceMappingURL=pptd-tools.d.ts.map
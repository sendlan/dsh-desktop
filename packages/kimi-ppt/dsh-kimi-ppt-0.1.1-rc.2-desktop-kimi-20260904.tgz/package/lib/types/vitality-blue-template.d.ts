/** Generated from the audited 58-page vitality-blue data-analysis reference PPTX. */
import type { OfficeTemplate } from './protocol.ts';
export declare const VITALITY_BLUE_TEMPLATE_DATA: Omit<OfficeTemplate, 'id' | 'origin'>;
//# sourceMappingURL=vitality-blue-template.d.ts.map